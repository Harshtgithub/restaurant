import { Restaurant, Staff, SalesRecord, Attendance } from '../types';

export const mockRestaurants: Restaurant[] = [
  {
    id: '1',
    name: 'Spice Garden',
    image: 'https://images.pexels.com/photos/67468/pexels-photo-67468.jpeg?auto=compress&cs=tinysrgb&w=800',
    cuisine: ['Indian', 'North Indian', 'Punjabi'],
    rating: 4.5,
    reviews: 1250,
    priceRange: '₹₹',
    address: 'Connaught Place, New Delhi',
    city: 'Delhi',
    phone: '+91 98765 43210',
    openingHours: '11:00 AM - 11:00 PM',
    features: ['AC', 'WiFi', 'Parking', 'Live Music'],
    tables: [
      { id: 't1', number: 1, capacity: 2, isAvailable: true },
      { id: 't2', number: 2, capacity: 4, isAvailable: true },
      { id: 't3', number: 3, capacity: 6, isAvailable: false },
    ],
    menu: [
      {
        id: 'm1',
        name: 'Butter Chicken',
        description: 'Creamy tomato-based curry with tender chicken pieces',
        price: 350,
        category: 'Main Course',
        image: 'https://images.pexels.com/photos/2338407/pexels-photo-2338407.jpeg?auto=compress&cs=tinysrgb&w=400',
        isVeg: false,
        isAvailable: true,
        preparationTime: 25
      },
      {
        id: 'm2',
        name: 'Paneer Tikka Masala',
        description: 'Grilled paneer in rich spiced gravy',
        price: 280,
        category: 'Main Course',
        image: 'https://images.pexels.com/photos/2474661/pexels-photo-2474661.jpeg?auto=compress&cs=tinysrgb&w=400',
        isVeg: true,
        isAvailable: true,
        preparationTime: 20
      }
    ]
  },
  {
    id: '2',
    name: 'Mumbai Darbar',
    image: 'https://images.pexels.com/photos/776538/pexels-photo-776538.jpeg?auto=compress&cs=tinysrgb&w=800',
    cuisine: ['Maharashtrian', 'Street Food', 'Seafood'],
    rating: 4.2,
    reviews: 890,
    priceRange: '₹₹',
    address: 'Bandra West, Mumbai',
    city: 'Mumbai',
    phone: '+91 98765 43211',
    openingHours: '12:00 PM - 12:00 AM',
    features: ['AC', 'WiFi', 'Valet Parking', 'Rooftop'],
    tables: [
      { id: 't4', number: 1, capacity: 2, isAvailable: true },
      { id: 't5', number: 2, capacity: 4, isAvailable: true }
    ],
    menu: [
      {
        id: 'm3',
        name: 'Vada Pav',
        description: 'Mumbai\'s iconic street food with spicy potato fritter',
        price: 45,
        category: 'Snacks',
        image: 'https://images.pexels.com/photos/5560763/pexels-photo-5560763.jpeg?auto=compress&cs=tinysrgb&w=400',
        isVeg: true,
        isAvailable: true,
        preparationTime: 10
      }
    ]
  },
  {
    id: '3',
    name: 'South Spice',
    image: 'https://images.pexels.com/photos/958545/pexels-photo-958545.jpeg?auto=compress&cs=tinysrgb&w=800',
    cuisine: ['South Indian', 'Tamil', 'Kerala'],
    rating: 4.7,
    reviews: 2100,
    priceRange: '₹₹₹',
    address: 'T. Nagar, Chennai',
    city: 'Chennai',
    phone: '+91 98765 43212',
    openingHours: '10:00 AM - 10:30 PM',
    features: ['AC', 'Family Friendly', 'Parking'],
    tables: [
      { id: 't6', number: 1, capacity: 4, isAvailable: true },
      { id: 't7', number: 2, capacity: 6, isAvailable: false }
    ],
    menu: [
      {
        id: 'm4',
        name: 'Masala Dosa',
        description: 'Crispy rice crepe with spiced potato filling',
        price: 120,
        category: 'Main Course',
        image: 'https://images.pexels.com/photos/5560027/pexels-photo-5560027.jpeg?auto=compress&cs=tinysrgb&w=400',
        isVeg: true,
        isAvailable: true,
        preparationTime: 15
      }
    ]
  }
];

export const mockStaff: Staff[] = [
  {
    id: 's1',
    name: 'Rahul Sharma',
    position: 'Head Chef',
    salary: 45000,
    phone: '+91 98765 11111',
    email: 'rahul@spicegarden.com',
    joinDate: '2023-01-15',
    isActive: true
  },
  {
    id: 's2',
    name: 'Priya Patel',
    position: 'Manager',
    salary: 35000,
    phone: '+91 98765 22222',
    email: 'priya@spicegarden.com',
    joinDate: '2023-03-01',
    isActive: true
  },
  {
    id: 's3',
    name: 'Amit Kumar',
    position: 'Waiter',
    salary: 18000,
    phone: '+91 98765 33333',
    email: 'amit@spicegarden.com',
    joinDate: '2023-06-10',
    isActive: true
  }
];

export const mockSalesData: SalesRecord[] = [
  {
    id: 'sr1',
    date: '2024-01-15',
    bookingId: 'b1',
    amount: 1200,
    gstAmount: 216,
    netAmount: 984,
    paymentMethod: 'UPI'
  },
  {
    id: 'sr2',
    date: '2024-01-15',
    bookingId: 'b2',
    amount: 800,
    gstAmount: 144,
    netAmount: 656,
    paymentMethod: 'Cash'
  },
  {
    id: 'sr3',
    date: '2024-01-14',
    bookingId: 'b3',
    amount: 1500,
    gstAmount: 270,
    netAmount: 1230,
    paymentMethod: 'Net Banking'
  }
];

export const mockAttendance: Attendance[] = [
  {
    id: 'a1',
    staffId: 's1',
    date: '2024-01-15',
    checkIn: '09:00',
    checkOut: '18:00',
    hoursWorked: 9,
    status: 'present'
  },
  {
    id: 'a2',
    staffId: 's2',
    date: '2024-01-15',
    checkIn: '10:00',
    checkOut: '19:00',
    hoursWorked: 9,
    status: 'present'
  },
  {
    id: 'a3',
    staffId: 's3',
    date: '2024-01-15',
    checkIn: '11:00',
    checkOut: '15:00',
    hoursWorked: 4,
    status: 'halfday'
  }
];

export const cities = [
  'Mumbai', 'Delhi', 'Bangalore', 'Chennai', 'Kolkata', 'Hyderabad', 
  'Pune', 'Ahmedabad', 'Jaipur', 'Surat', 'Lucknow', 'Kanpur'
];

export const cuisineTypes = [
  'North Indian', 'South Indian', 'Chinese', 'Continental', 'Italian',
  'Mexican', 'Thai', 'Punjabi', 'Gujarati', 'Bengali', 'Maharashtrian'
];