import React, { useState } from 'react';
import { Plus, Minus, Clock, Leaf } from 'lucide-react';
import { MenuItem } from '../../types';
import { formatCurrency } from '../../utils/formatters';

interface MenuCardProps {
  item: MenuItem;
  onAddToCart: (item: MenuItem, quantity: number) => void;
}

const MenuCard: React.FC<MenuCardProps> = ({ item, onAddToCart }) => {
  const [quantity, setQuantity] = useState(0);

  const handleQuantityChange = (newQuantity: number) => {
    setQuantity(newQuantity);
    if (newQuantity > 0) {
      onAddToCart(item, newQuantity);
    }
  };

  return (
    <div className="bg-white rounded-lg shadow-md p-4 hover:shadow-lg transition-shadow duration-300">
      <div className="flex space-x-4">
        <img
          src={item.image}
          alt={item.name}
          className="w-20 h-20 object-cover rounded-lg"
        />
        
        <div className="flex-1">
          <div className="flex items-start justify-between mb-2">
            <div>
              <div className="flex items-center space-x-2">
                <h3 className="font-semibold text-gray-900">{item.name}</h3>
                {item.isVeg && (
                  <div className="flex items-center justify-center w-4 h-4 border border-green-500">
                    <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                  </div>
                )}
              </div>
              <p className="text-sm text-gray-600 mt-1">{item.description}</p>
            </div>
            
            <div className="text-right">
              <p className="font-bold text-lg text-gray-900">{formatCurrency(item.price)}</p>
              {!item.isAvailable && (
                <span className="text-xs text-red-500 font-medium">Out of stock</span>
              )}
            </div>
          </div>

          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2 text-sm text-gray-500">
              <Clock className="h-4 w-4" />
              <span>{item.preparationTime} mins</span>
            </div>

            {item.isAvailable ? (
              <div className="flex items-center space-x-3">
                {quantity === 0 ? (
                  <button
                    onClick={() => handleQuantityChange(1)}
                    className="bg-primary-500 text-white px-4 py-1 rounded-lg hover:bg-primary-600 transition-colors duration-200 text-sm font-medium"
                  >
                    ADD
                  </button>
                ) : (
                  <div className="flex items-center space-x-2">
                    <button
                      onClick={() => handleQuantityChange(Math.max(0, quantity - 1))}
                      className="w-8 h-8 bg-primary-100 text-primary-600 rounded-full flex items-center justify-center hover:bg-primary-200 transition-colors duration-200"
                    >
                      <Minus className="h-4 w-4" />
                    </button>
                    <span className="font-semibold text-primary-600 w-8 text-center">{quantity}</span>
                    <button
                      onClick={() => handleQuantityChange(quantity + 1)}
                      className="w-8 h-8 bg-primary-100 text-primary-600 rounded-full flex items-center justify-center hover:bg-primary-200 transition-colors duration-200"
                    >
                      <Plus className="h-4 w-4" />
                    </button>
                  </div>
                )}
              </div>
            ) : (
              <button
                disabled
                className="bg-gray-300 text-gray-500 px-4 py-1 rounded-lg text-sm font-medium cursor-not-allowed"
              >
                Unavailable
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default MenuCard;