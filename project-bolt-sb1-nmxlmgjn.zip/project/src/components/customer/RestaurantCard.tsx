import React from 'react';
import { Link } from 'react-router-dom';
import { Star, MapPin, Clock, Users, Wifi, Car } from 'lucide-react';
import { Restaurant } from '../../types';
import { formatCurrency } from '../../utils/formatters';

interface RestaurantCardProps {
  restaurant: Restaurant;
}

const RestaurantCard: React.FC<RestaurantCardProps> = ({ restaurant }) => {
  const getFeatureIcon = (feature: string) => {
    switch (feature.toLowerCase()) {
      case 'wifi':
        return <Wifi className="h-4 w-4" />;
      case 'parking':
        return <Car className="h-4 w-4" />;
      case 'ac':
        return <span className="text-xs font-semibold">AC</span>;
      default:
        return null;
    }
  };

  return (
    <div className="bg-white rounded-xl shadow-md overflow-hidden hover:shadow-lg transition-shadow duration-300 animate-fade-in">
      <div className="relative">
        <img
          src={restaurant.image}
          alt={restaurant.name}
          className="w-full h-48 object-cover"
        />
        <div className="absolute top-4 right-4 bg-white rounded-full px-2 py-1 flex items-center space-x-1">
          <Star className="h-4 w-4 text-yellow-400 fill-current" />
          <span className="text-sm font-semibold">{restaurant.rating}</span>
        </div>
        <div className="absolute bottom-4 left-4 bg-black bg-opacity-50 text-white px-2 py-1 rounded text-sm">
          {restaurant.priceRange}
        </div>
      </div>

      <div className="p-6">
        <div className="flex justify-between items-start mb-2">
          <h3 className="text-xl font-bold text-gray-900">{restaurant.name}</h3>
          <span className="text-sm text-gray-500">({restaurant.reviews} reviews)</span>
        </div>

        <div className="flex items-center space-x-2 text-gray-600 mb-3">
          <MapPin className="h-4 w-4" />
          <span className="text-sm">{restaurant.address}</span>
        </div>

        <div className="flex items-center space-x-2 text-gray-600 mb-3">
          <Clock className="h-4 w-4" />
          <span className="text-sm">{restaurant.openingHours}</span>
        </div>

        <div className="flex flex-wrap gap-2 mb-4">
          {restaurant.cuisine.slice(0, 3).map((cuisineType, index) => (
            <span
              key={index}
              className="px-2 py-1 bg-primary-100 text-primary-700 text-xs rounded-full"
            >
              {cuisineType}
            </span>
          ))}
        </div>

        <div className="flex items-center justify-between mb-4">
          <div className="flex space-x-3">
            {restaurant.features.slice(0, 4).map((feature, index) => (
              <div
                key={index}
                className="flex items-center justify-center w-8 h-8 bg-gray-100 rounded-full text-gray-600"
                title={feature}
              >
                {getFeatureIcon(feature)}
              </div>
            ))}
          </div>
          <div className="flex items-center space-x-1 text-sm text-gray-600">
            <Users className="h-4 w-4" />
            <span>{restaurant.tables.filter(t => t.isAvailable).length} tables available</span>
          </div>
        </div>

        <div className="flex space-x-3">
          <Link
            to={`/restaurant/${restaurant.id}`}
            className="flex-1 bg-primary-500 text-white text-center py-2 px-4 rounded-lg hover:bg-primary-600 transition-colors duration-200 font-medium"
          >
            View Details
          </Link>
          <Link
            to={`/restaurant/${restaurant.id}/book`}
            className="flex-1 bg-white border-2 border-primary-500 text-primary-500 text-center py-2 px-4 rounded-lg hover:bg-primary-500 hover:text-white transition-colors duration-200 font-medium"
          >
            Book Table
          </Link>
        </div>
      </div>
    </div>
  );
};

export default RestaurantCard;