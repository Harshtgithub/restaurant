import React, { useState } from 'react';
import { Plus, Minus, Trash2, Calculator, Printer, Save } from 'lucide-react';
import { MenuItem } from '../../types';
import { formatCurrency, calculateGST } from '../../utils/formatters';

interface BillItem {
  menuItem: MenuItem;
  quantity: number;
  notes?: string;
}

interface BillMakerProps {
  menu: MenuItem[];
  onSaveBill: (bill: any) => void;
}

const BillMaker: React.FC<BillMakerProps> = ({ menu, onSaveBill }) => {
  const [billItems, setBillItems] = useState<BillItem[]>([]);
  const [customerName, setCustomerName] = useState('');
  const [customerPhone, setCustomerPhone] = useState('');
  const [tableNumber, setTableNumber] = useState('');
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('');
  const [paymentMethod, setPaymentMethod] = useState<'cash' | 'upi' | 'card'>('cash');
  const [discount, setDiscount] = useState(0);

  const categories = [...new Set(menu.map(item => item.category))];
  
  const filteredMenu = menu.filter(item => {
    const matchesSearch = item.name.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory = !selectedCategory || item.category === selectedCategory;
    return matchesSearch && matchesCategory && item.isAvailable;
  });

  const addItemToBill = (menuItem: MenuItem) => {
    setBillItems(prev => {
      const existingItem = prev.find(item => item.menuItem.id === menuItem.id);
      if (existingItem) {
        return prev.map(item =>
          item.menuItem.id === menuItem.id
            ? { ...item, quantity: item.quantity + 1 }
            : item
        );
      } else {
        return [...prev, { menuItem, quantity: 1 }];
      }
    });
  };

  const updateQuantity = (menuItemId: string, newQuantity: number) => {
    if (newQuantity <= 0) {
      setBillItems(prev => prev.filter(item => item.menuItem.id !== menuItemId));
    } else {
      setBillItems(prev =>
        prev.map(item =>
          item.menuItem.id === menuItemId
            ? { ...item, quantity: newQuantity }
            : item
        )
      );
    }
  };

  const removeItem = (menuItemId: string) => {
    setBillItems(prev => prev.filter(item => item.menuItem.id !== menuItemId));
  };

  const subtotal = billItems.reduce((total, item) => total + (item.menuItem.price * item.quantity), 0);
  const discountAmount = (subtotal * discount) / 100;
  const discountedAmount = subtotal - discountAmount;
  const gstAmount = calculateGST(discountedAmount);
  const totalAmount = discountedAmount + gstAmount;

  const generateBill = () => {
    const bill = {
      id: `BILL-${Date.now()}`,
      customerName,
      customerPhone,
      tableNumber,
      items: billItems,
      subtotal,
      discount,
      discountAmount,
      gstAmount,
      totalAmount,
      paymentMethod,
      timestamp: new Date().toISOString(),
      billNumber: `INV-${Date.now().toString().slice(-6)}`
    };

    onSaveBill(bill);
    
    // Reset form
    setBillItems([]);
    setCustomerName('');
    setCustomerPhone('');
    setTableNumber('');
    setDiscount(0);
    
    // Print bill (in real app, this would trigger actual printing)
    printBill(bill);
  };

  const printBill = (bill: any) => {
    const printWindow = window.open('', '_blank');
    if (printWindow) {
      printWindow.document.write(`
        <html>
          <head>
            <title>Bill - ${bill.billNumber}</title>
            <style>
              body { font-family: Arial, sans-serif; margin: 20px; }
              .header { text-align: center; border-bottom: 2px solid #000; padding-bottom: 10px; margin-bottom: 20px; }
              .bill-details { margin-bottom: 20px; }
              .items-table { width: 100%; border-collapse: collapse; margin-bottom: 20px; }
              .items-table th, .items-table td { border: 1px solid #ddd; padding: 8px; text-align: left; }
              .items-table th { background-color: #f2f2f2; }
              .totals { text-align: right; }
              .total-row { font-weight: bold; font-size: 1.2em; }
              .footer { margin-top: 30px; text-align: center; font-size: 0.9em; color: #666; }
            </style>
          </head>
          <body>
            <div class="header">
              <h1>Spice Garden</h1>
              <p>Connaught Place, New Delhi | Phone: +91 98765 43210</p>
              <p>GSTIN: 07AAACH7409R1ZZ</p>
            </div>
            
            <div class="bill-details">
              <p><strong>Bill No:</strong> ${bill.billNumber}</p>
              <p><strong>Date:</strong> ${new Date(bill.timestamp).toLocaleDateString('en-IN')}</p>
              <p><strong>Time:</strong> ${new Date(bill.timestamp).toLocaleTimeString('en-IN')}</p>
              ${bill.customerName ? `<p><strong>Customer:</strong> ${bill.customerName}</p>` : ''}
              ${bill.customerPhone ? `<p><strong>Phone:</strong> ${bill.customerPhone}</p>` : ''}
              ${bill.tableNumber ? `<p><strong>Table:</strong> ${bill.tableNumber}</p>` : ''}
              <p><strong>Payment:</strong> ${bill.paymentMethod.toUpperCase()}</p>
            </div>

            <table class="items-table">
              <thead>
                <tr>
                  <th>Item</th>
                  <th>Qty</th>
                  <th>Rate</th>
                  <th>Amount</th>
                </tr>
              </thead>
              <tbody>
                ${bill.items.map((item: BillItem) => `
                  <tr>
                    <td>${item.menuItem.name}</td>
                    <td>${item.quantity}</td>
                    <td>₹${item.menuItem.price}</td>
                    <td>₹${item.menuItem.price * item.quantity}</td>
                  </tr>
                `).join('')}
              </tbody>
            </table>

            <div class="totals">
              <p>Subtotal: ₹${bill.subtotal}</p>
              ${bill.discount > 0 ? `<p>Discount (${bill.discount}%): -₹${bill.discountAmount}</p>` : ''}
              <p>CGST (9%): ₹${(bill.gstAmount / 2).toFixed(2)}</p>
              <p>SGST (9%): ₹${(bill.gstAmount / 2).toFixed(2)}</p>
              <p class="total-row">Total: ₹${bill.totalAmount}</p>
            </div>

            <div class="footer">
              <p>Thank you for dining with us!</p>
              <p>Visit us again soon</p>
            </div>
          </body>
        </html>
      `);
      printWindow.document.close();
      printWindow.print();
    }
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
      {/* Menu Selection */}
      <div className="lg:col-span-2 space-y-6">
        <div className="bg-white rounded-lg shadow-md p-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Select Items</h3>
          
          {/* Search and Filter */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
            <input
              type="text"
              placeholder="Search menu items..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-primary-500"
            />
            <select
              value={selectedCategory}
              onChange={(e) => setSelectedCategory(e.target.value)}
              className="px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-primary-500"
            >
              <option value="">All Categories</option>
              {categories.map(category => (
                <option key={category} value={category}>{category}</option>
              ))}
            </select>
          </div>

          {/* Menu Items Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 max-h-96 overflow-y-auto">
            {filteredMenu.map(item => (
              <div
                key={item.id}
                className="border border-gray-200 rounded-lg p-4 hover:shadow-md transition-shadow cursor-pointer"
                onClick={() => addItemToBill(item)}
              >
                <div className="flex justify-between items-start mb-2">
                  <div className="flex-1">
                    <div className="flex items-center space-x-2">
                      <h4 className="font-medium text-gray-900">{item.name}</h4>
                      {item.isVeg && (
                        <div className="flex items-center justify-center w-4 h-4 border border-green-500">
                          <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                        </div>
                      )}
                    </div>
                    <p className="text-sm text-gray-600 mt-1">{item.description}</p>
                  </div>
                  <div className="text-right ml-4">
                    <p className="font-semibold text-gray-900">{formatCurrency(item.price)}</p>
                    <button className="mt-1 bg-primary-500 text-white px-3 py-1 rounded text-sm hover:bg-primary-600 transition-colors">
                      <Plus className="h-3 w-3" />
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Bill Summary */}
      <div className="space-y-6">
        {/* Customer Details */}
        <div className="bg-white rounded-lg shadow-md p-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Customer Details</h3>
          <div className="space-y-4">
            <input
              type="text"
              placeholder="Customer Name (Optional)"
              value={customerName}
              onChange={(e) => setCustomerName(e.target.value)}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-primary-500"
            />
            <input
              type="tel"
              placeholder="Phone Number (Optional)"
              value={customerPhone}
              onChange={(e) => setCustomerPhone(e.target.value)}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-primary-500"
            />
            <input
              type="text"
              placeholder="Table Number"
              value={tableNumber}
              onChange={(e) => setTableNumber(e.target.value)}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-primary-500"
            />
          </div>
        </div>

        {/* Bill Items */}
        <div className="bg-white rounded-lg shadow-md p-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Bill Items</h3>
          
          {billItems.length === 0 ? (
            <div className="text-center py-8 text-gray-500">
              <Calculator className="h-12 w-12 mx-auto mb-2 text-gray-300" />
              <p>No items added yet</p>
            </div>
          ) : (
            <div className="space-y-3 mb-4">
              {billItems.map(item => (
                <div key={item.menuItem.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                  <div className="flex-1">
                    <p className="font-medium text-gray-900">{item.menuItem.name}</p>
                    <p className="text-sm text-gray-600">{formatCurrency(item.menuItem.price)} each</p>
                  </div>
                  <div className="flex items-center space-x-2">
                    <button
                      onClick={() => updateQuantity(item.menuItem.id, item.quantity - 1)}
                      className="w-8 h-8 bg-gray-200 text-gray-600 rounded-full flex items-center justify-center hover:bg-gray-300 transition-colors"
                    >
                      <Minus className="h-4 w-4" />
                    </button>
                    <span className="font-semibold text-gray-900 w-8 text-center">{item.quantity}</span>
                    <button
                      onClick={() => updateQuantity(item.menuItem.id, item.quantity + 1)}
                      className="w-8 h-8 bg-gray-200 text-gray-600 rounded-full flex items-center justify-center hover:bg-gray-300 transition-colors"
                    >
                      <Plus className="h-4 w-4" />
                    </button>
                    <button
                      onClick={() => removeItem(item.menuItem.id)}
                      className="w-8 h-8 bg-red-100 text-red-600 rounded-full flex items-center justify-center hover:bg-red-200 transition-colors ml-2"
                    >
                      <Trash2 className="h-4 w-4" />
                    </button>
                  </div>
                  <div className="text-right ml-4">
                    <p className="font-semibold text-gray-900">
                      {formatCurrency(item.menuItem.price * item.quantity)}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          )}

          {/* Discount */}
          {billItems.length > 0 && (
            <div className="mb-4">
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Discount (%)
              </label>
              <input
                type="number"
                min="0"
                max="100"
                value={discount}
                onChange={(e) => setDiscount(Number(e.target.value))}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-primary-500"
              />
            </div>
          )}

          {/* Payment Method */}
          {billItems.length > 0 && (
            <div className="mb-4">
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Payment Method
              </label>
              <select
                value={paymentMethod}
                onChange={(e) => setPaymentMethod(e.target.value as any)}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-primary-500"
              >
                <option value="cash">Cash</option>
                <option value="upi">UPI</option>
                <option value="card">Card</option>
              </select>
            </div>
          )}

          {/* Bill Summary */}
          {billItems.length > 0 && (
            <div className="border-t border-gray-200 pt-4 space-y-2">
              <div className="flex justify-between">
                <span className="text-gray-600">Subtotal</span>
                <span className="font-medium">{formatCurrency(subtotal)}</span>
              </div>
              {discount > 0 && (
                <div className="flex justify-between text-green-600">
                  <span>Discount ({discount}%)</span>
                  <span>-{formatCurrency(discountAmount)}</span>
                </div>
              )}
              <div className="flex justify-between">
                <span className="text-gray-600">CGST (9%)</span>
                <span className="font-medium">{formatCurrency(gstAmount / 2)}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-600">SGST (9%)</span>
                <span className="font-medium">{formatCurrency(gstAmount / 2)}</span>
              </div>
              <div className="border-t border-gray-200 pt-2">
                <div className="flex justify-between font-bold text-lg">
                  <span>Total</span>
                  <span>{formatCurrency(totalAmount)}</span>
                </div>
              </div>
            </div>
          )}

          {/* Action Buttons */}
          {billItems.length > 0 && (
            <div className="flex space-x-3 mt-6">
              <button
                onClick={generateBill}
                className="flex-1 bg-primary-500 text-white py-2 px-4 rounded-lg hover:bg-primary-600 transition-colors flex items-center justify-center space-x-2"
              >
                <Printer className="h-4 w-4" />
                <span>Generate Bill</span>
              </button>
              <button
                onClick={() => setBillItems([])}
                className="px-4 py-2 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors"
              >
                Clear
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default BillMaker;