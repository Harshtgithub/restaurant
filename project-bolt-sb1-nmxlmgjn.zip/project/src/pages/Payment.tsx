import React, { useState } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import { CreditCard, Smartphone, Banknote, Check, ArrowLeft } from 'lucide-react';
import Button from '../components/common/Button';
import { formatCurrency, calculateGST } from '../utils/formatters';

const Payment = () => {
  const location = useLocation();
  const navigate = useNavigate();
  const [paymentMethod, setPaymentMethod] = useState<'upi' | 'netbanking' | 'cash'>('upi');
  const [processing, setProcessing] = useState(false);
  const [completed, setCompleted] = useState(false);

  const { restaurant, booking } = location.state || {};

  if (!restaurant || !booking) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <h2 className="text-2xl font-bold text-gray-900 mb-4">Invalid booking data</h2>
          <Button onClick={() => navigate('/restaurants')}>
            Back to Restaurants
          </Button>
        </div>
      </div>
    );
  }

  const subtotal = booking.totalAmount || 0;
  const tableBookingFee = 50; // Fixed booking fee
  const gstAmount = calculateGST(subtotal + tableBookingFee);
  const totalAmount = subtotal + tableBookingFee + gstAmount;

  const handlePayment = async () => {
    setProcessing(true);
    
    // Simulate payment processing
    await new Promise(resolve => setTimeout(resolve, 2000));
    
    setProcessing(false);
    setCompleted(true);
    
    // Redirect to success page after 2 seconds
    setTimeout(() => {
      navigate('/customer-dashboard', { 
        state: { bookingConfirmed: true }
      });
    }, 2000);
  };

  if (completed) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="max-w-md w-full bg-white rounded-lg shadow-lg p-8 text-center">
          <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
            <Check className="h-8 w-8 text-green-600" />
          </div>
          <h2 className="text-2xl font-bold text-gray-900 mb-2">Booking Confirmed!</h2>
          <p className="text-gray-600 mb-4">
            Your table has been reserved at {restaurant.name}
          </p>
          <div className="bg-gray-50 rounded-lg p-4 mb-4">
            <div className="text-sm space-y-1">
              <div className="flex justify-between">
                <span>Date:</span>
                <span className="font-medium">{booking.date}</span>
              </div>
              <div className="flex justify-between">
                <span>Time:</span>
                <span className="font-medium">{booking.time}</span>
              </div>
              <div className="flex justify-between">
                <span>Guests:</span>
                <span className="font-medium">{booking.guests}</span>
              </div>
            </div>
          </div>
          <p className="text-sm text-gray-500">
            Redirecting to your dashboard...
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="mb-6">
          <button
            onClick={() => navigate(-1)}
            className="flex items-center text-gray-600 hover:text-gray-900 mb-4"
          >
            <ArrowLeft className="h-5 w-5 mr-2" />
            Back to Restaurant
          </button>
          <h1 className="text-3xl font-bold text-gray-900">Complete Your Booking</h1>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Booking Summary */}
          <div className="space-y-6">
            <div className="bg-white rounded-lg shadow-md p-6">
              <h2 className="text-xl font-semibold text-gray-900 mb-4">Booking Summary</h2>
              
              <div className="space-y-3 mb-4">
                <div className="flex justify-between">
                  <span className="text-gray-600">Restaurant</span>
                  <span className="font-medium">{restaurant.name}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Date</span>
                  <span className="font-medium">{booking.date}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Time</span>
                  <span className="font-medium">{booking.time}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Guests</span>
                  <span className="font-medium">{booking.guests}</span>
                </div>
              </div>

              {booking.preOrder && booking.preOrder.length > 0 && (
                <div className="border-t border-gray-200 pt-4">
                  <h3 className="font-medium text-gray-900 mb-3">Pre-order Items</h3>
                  <div className="space-y-2">
                    {booking.preOrder.map((item: any) => {
                      const menuItem = restaurant.menu.find((m: any) => m.id === item.menuItemId);
                      return (
                        <div key={item.menuItemId} className="flex justify-between text-sm">
                          <span>{menuItem?.name} x {item.quantity}</span>
                          <span>{formatCurrency(menuItem?.price * item.quantity)}</span>
                        </div>
                      );
                    })}
                  </div>
                </div>
              )}
            </div>

            {/* Bill Breakdown */}
            <div className="bg-white rounded-lg shadow-md p-6">
              <h2 className="text-xl font-semibold text-gray-900 mb-4">Bill Breakdown</h2>
              
              <div className="space-y-3">
                {subtotal > 0 && (
                  <div className="flex justify-between">
                    <span className="text-gray-600">Food Total</span>
                    <span>{formatCurrency(subtotal)}</span>
                  </div>
                )}
                <div className="flex justify-between">
                  <span className="text-gray-600">Table Booking Fee</span>
                  <span>{formatCurrency(tableBookingFee)}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">GST (18%)</span>
                  <span>{formatCurrency(gstAmount)}</span>
                </div>
                <div className="border-t border-gray-200 pt-3">
                  <div className="flex justify-between font-semibold text-lg">
                    <span>Total Amount</span>
                    <span>{formatCurrency(totalAmount)}</span>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Payment Methods */}
          <div className="space-y-6">
            <div className="bg-white rounded-lg shadow-md p-6">
              <h2 className="text-xl font-semibold text-gray-900 mb-4">Payment Method</h2>
              
              <div className="space-y-3 mb-6">
                <div
                  className={`border rounded-lg p-4 cursor-pointer transition-colors ${
                    paymentMethod === 'upi' ? 'border-primary-500 bg-primary-50' : 'border-gray-200 hover:border-gray-300'
                  }`}
                  onClick={() => setPaymentMethod('upi')}
                >
                  <div className="flex items-center">
                    <Smartphone className="h-6 w-6 text-primary-500 mr-3" />
                    <div>
                      <h3 className="font-medium text-gray-900">UPI Payment</h3>
                      <p className="text-sm text-gray-600">Pay using Google Pay, PhonePe, Paytm, etc.</p>
                    </div>
                  </div>
                </div>

                <div
                  className={`border rounded-lg p-4 cursor-pointer transition-colors ${
                    paymentMethod === 'netbanking' ? 'border-primary-500 bg-primary-50' : 'border-gray-200 hover:border-gray-300'
                  }`}
                  onClick={() => setPaymentMethod('netbanking')}
                >
                  <div className="flex items-center">
                    <CreditCard className="h-6 w-6 text-primary-500 mr-3" />
                    <div>
                      <h3 className="font-medium text-gray-900">Net Banking</h3>
                      <p className="text-sm text-gray-600">Pay using your bank account</p>
                    </div>
                  </div>
                </div>

                <div
                  className={`border rounded-lg p-4 cursor-pointer transition-colors ${
                    paymentMethod === 'cash' ? 'border-primary-500 bg-primary-50' : 'border-gray-200 hover:border-gray-300'
                  }`}
                  onClick={() => setPaymentMethod('cash')}
                >
                  <div className="flex items-center">
                    <Banknote className="h-6 w-6 text-primary-500 mr-3" />
                    <div>
                      <h3 className="font-medium text-gray-900">Pay at Restaurant</h3>
                      <p className="text-sm text-gray-600">Pay with cash when you arrive</p>
                    </div>
                  </div>
                </div>
              </div>

              {paymentMethod === 'upi' && (
                <div className="mb-6">
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    UPI ID
                  </label>
                  <input
                    type="text"
                    placeholder="your-upi@bank"
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-primary-500"
                  />
                </div>
              )}

              {paymentMethod === 'netbanking' && (
                <div className="mb-6">
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Select Bank
                  </label>
                  <select className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-primary-500">
                    <option value="">Choose your bank</option>
                    <option value="sbi">State Bank of India</option>
                    <option value="hdfc">HDFC Bank</option>
                    <option value="icici">ICICI Bank</option>
                    <option value="axis">Axis Bank</option>
                  </select>
                </div>
              )}

              <Button
                className="w-full"
                loading={processing}
                onClick={handlePayment}
              >
                {processing 
                  ? 'Processing Payment...' 
                  : paymentMethod === 'cash' 
                    ? 'Confirm Booking' 
                    : `Pay ${formatCurrency(totalAmount)}`
                }
              </Button>

              <div className="mt-4 text-center text-sm text-gray-500">
                <p>Your payment is secured with 256-bit SSL encryption</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Payment;