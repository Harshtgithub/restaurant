import React, { useState } from 'react';
import { BarChart3, Users, DollarSign, Calendar, TrendingUp, Clock, Utensils, Star, Receipt } from 'lucide-react';
import SalesChart from '../components/restaurant/SalesChart';
import BillMaker from '../components/restaurant/BillMaker';
import { mockSalesData, mockStaff, mockAttendance, mockRestaurants } from '../data/mockData';
import { formatCurrency } from '../utils/formatters';

const RestaurantDashboard = () => {
  const [activeTab, setActiveTab] = useState<'overview' | 'orders' | 'staff' | 'analytics' | 'billing'>('overview');
  const [bills, setBills] = useState<any[]>([]);

  // Mock data for charts
  const salesChartData = [
    { date: '2024-01-10', sales: 15000, orders: 45 },
    { date: '2024-01-11', sales: 18000, orders: 52 },
    { date: '2024-01-12', sales: 22000, orders: 61 },
    { date: '2024-01-13', sales: 19000, orders: 48 },
    { date: '2024-01-14', sales: 25000, orders: 67 },
    { date: '2024-01-15', sales: 28000, orders: 72 },
  ];

  const todaysStats = {
    totalSales: 28000,
    totalOrders: 72,
    avgOrderValue: 389,
    staffPresent: 8,
    totalStaff: 10,
    rating: 4.6
  };

  const recentOrders = [
    { id: 'ORD001', customer: 'Rahul Sharma', items: 3, amount: 850, status: 'preparing', time: '2:30 PM' },
    { id: 'ORD002', customer: 'Priya Patel', items: 2, amount: 450, status: 'ready', time: '2:15 PM' },
    { id: 'ORD003', customer: 'Amit Kumar', items: 4, amount: 720, status: 'delivered', time: '1:45 PM' },
    { id: 'ORD004', customer: 'Sneha Singh', items: 1, amount: 280, status: 'confirmed', time: '2:45 PM' },
  ];

  const handleSaveBill = (bill: any) => {
    setBills(prev => [bill, ...prev]);
    // In a real app, this would save to database
    console.log('Bill saved:', bill);
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'confirmed': return 'bg-blue-100 text-blue-800';
      case 'preparing': return 'bg-yellow-100 text-yellow-800';
      case 'ready': return 'bg-green-100 text-green-800';
      case 'delivered': return 'bg-gray-100 text-gray-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  // Get restaurant menu (using first restaurant as example)
  const restaurantMenu = mockRestaurants[0]?.menu || [];

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900">Restaurant Dashboard</h1>
          <p className="text-gray-600 mt-2">Welcome back! Here's what's happening at Spice Garden today.</p>
        </div>

        {/* Stats Overview */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <div className="bg-white rounded-lg shadow-md p-6">
            <div className="flex items-center">
              <div className="p-3 bg-primary-100 rounded-lg">
                <DollarSign className="h-6 w-6 text-primary-600" />
              </div>
              <div className="ml-4">
                <p className="text-sm font-medium text-gray-600">Today's Sales</p>
                <p className="text-2xl font-bold text-gray-900">{formatCurrency(todaysStats.totalSales)}</p>
              </div>
            </div>
          </div>

          <div className="bg-white rounded-lg shadow-md p-6">
            <div className="flex items-center">
              <div className="p-3 bg-secondary-100 rounded-lg">
                <Utensils className="h-6 w-6 text-secondary-600" />
              </div>
              <div className="ml-4">
                <p className="text-sm font-medium text-gray-600">Orders</p>
                <p className="text-2xl font-bold text-gray-900">{todaysStats.totalOrders}</p>
              </div>
            </div>
          </div>

          <div className="bg-white rounded-lg shadow-md p-6">
            <div className="flex items-center">
              <div className="p-3 bg-accent-100 rounded-lg">
                <Users className="h-6 w-6 text-accent-600" />
              </div>
              <div className="ml-4">
                <p className="text-sm font-medium text-gray-600">Staff Present</p>
                <p className="text-2xl font-bold text-gray-900">{todaysStats.staffPresent}/{todaysStats.totalStaff}</p>
              </div>
            </div>
          </div>

          <div className="bg-white rounded-lg shadow-md p-6">
            <div className="flex items-center">
              <div className="p-3 bg-yellow-100 rounded-lg">
                <Star className="h-6 w-6 text-yellow-600" />
              </div>
              <div className="ml-4">
                <p className="text-sm font-medium text-gray-600">Rating</p>
                <p className="text-2xl font-bold text-gray-900">{todaysStats.rating}</p>
              </div>
            </div>
          </div>
        </div>

        {/* Tabs */}
        <div className="bg-white rounded-lg shadow-md mb-8">
          <div className="border-b border-gray-200">
            <nav className="flex space-x-8 px-6">
              {[
                { id: 'overview', label: 'Overview', icon: BarChart3 },
                { id: 'orders', label: 'Orders', icon: Utensils },
                { id: 'billing', label: 'Billing', icon: Receipt },
                { id: 'staff', label: 'Staff', icon: Users },
                { id: 'analytics', label: 'Analytics', icon: TrendingUp }
              ].map(tab => (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id as any)}
                  className={`flex items-center space-x-2 py-4 px-1 border-b-2 font-medium text-sm ${
                    activeTab === tab.id
                      ? 'border-primary-500 text-primary-600'
                      : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
                  }`}
                >
                  <tab.icon className="h-4 w-4" />
                  <span>{tab.label}</span>
                </button>
              ))}
            </nav>
          </div>

          <div className="p-6">
            {activeTab === 'overview' && (
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                <div>
                  <h3 className="text-lg font-semibold text-gray-900 mb-4">Recent Orders</h3>
                  <div className="space-y-3">
                    {recentOrders.map(order => (
                      <div key={order.id} className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                        <div>
                          <p className="font-medium text-gray-900">{order.customer}</p>
                          <p className="text-sm text-gray-600">{order.items} items • {order.time}</p>
                        </div>
                        <div className="text-right">
                          <p className="font-semibold text-gray-900">{formatCurrency(order.amount)}</p>
                          <span className={`px-2 py-1 text-xs font-medium rounded-full ${getStatusColor(order.status)}`}>
                            {order.status}
                          </span>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                <div>
                  <h3 className="text-lg font-semibold text-gray-900 mb-4">Today's Highlights</h3>
                  <div className="space-y-4">
                    <div className="p-4 bg-green-50 rounded-lg border border-green-200">
                      <div className="flex items-center">
                        <TrendingUp className="h-5 w-5 text-green-600 mr-2" />
                        <span className="text-green-800 font-medium">Sales up 15% from yesterday</span>
                      </div>
                    </div>
                    <div className="p-4 bg-blue-50 rounded-lg border border-blue-200">
                      <div className="flex items-center">
                        <Clock className="h-5 w-5 text-blue-600 mr-2" />
                        <span className="text-blue-800 font-medium">Average prep time: 18 minutes</span>
                      </div>
                    </div>
                    <div className="p-4 bg-yellow-50 rounded-lg border border-yellow-200">
                      <div className="flex items-center">
                        <Star className="h-5 w-5 text-yellow-600 mr-2" />
                        <span className="text-yellow-800 font-medium">3 new 5-star reviews</span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {activeTab === 'orders' && (
              <div>
                <div className="flex justify-between items-center mb-6">
                  <h3 className="text-lg font-semibold text-gray-900">Order Management</h3>
                  <div className="flex space-x-2">
                    <button className="px-4 py-2 bg-primary-500 text-white rounded-lg hover:bg-primary-600 transition-colors">
                      New Order
                    </button>
                  </div>
                </div>

                <div className="overflow-x-auto">
                  <table className="min-w-full divide-y divide-gray-200">
                    <thead className="bg-gray-50">
                      <tr>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                          Order ID
                        </th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                          Customer
                        </th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                          Items
                        </th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                          Amount
                        </th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                          Status
                        </th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                          Time
                        </th>
                      </tr>
                    </thead>
                    <tbody className="bg-white divide-y divide-gray-200">
                      {recentOrders.map(order => (
                        <tr key={order.id}>
                          <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                            {order.id}
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                            {order.customer}
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                            {order.items} items
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                            {formatCurrency(order.amount)}
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap">
                            <span className={`px-2 py-1 text-xs font-medium rounded-full ${getStatusColor(order.status)}`}>
                              {order.status}
                            </span>
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                            {order.time}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            )}

            {activeTab === 'billing' && (
              <div>
                <div className="mb-6">
                  <h3 className="text-lg font-semibold text-gray-900 mb-2">Offline Customer Billing</h3>
                  <p className="text-gray-600">Create bills for walk-in customers and manage offline orders</p>
                </div>

                <BillMaker menu={restaurantMenu} onSaveBill={handleSaveBill} />

                {/* Recent Bills */}
                {bills.length > 0 && (
                  <div className="mt-8">
                    <h4 className="text-lg font-semibold text-gray-900 mb-4">Recent Bills</h4>
                    <div className="bg-white rounded-lg shadow-md overflow-hidden">
                      <div className="overflow-x-auto">
                        <table className="min-w-full divide-y divide-gray-200">
                          <thead className="bg-gray-50">
                            <tr>
                              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                Bill No.
                              </th>
                              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                Customer
                              </th>
                              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                Table
                              </th>
                              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                Amount
                              </th>
                              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                Payment
                              </th>
                              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                Time
                              </th>
                            </tr>
                          </thead>
                          <tbody className="bg-white divide-y divide-gray-200">
                            {bills.map(bill => (
                              <tr key={bill.id}>
                                <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                                  {bill.billNumber}
                                </td>
                                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                                  {bill.customerName || 'Walk-in Customer'}
                                </td>
                                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                                  {bill.tableNumber || '-'}
                                </td>
                                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                                  {formatCurrency(bill.totalAmount)}
                                </td>
                                <td className="px-6 py-4 whitespace-nowrap">
                                  <span className="px-2 py-1 text-xs font-medium rounded-full bg-green-100 text-green-800">
                                    {bill.paymentMethod.toUpperCase()}
                                  </span>
                                </td>
                                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                                  {new Date(bill.timestamp).toLocaleTimeString('en-IN')}
                                </td>
                              </tr>
                            ))}
                          </tbody>
                        </table>
                      </div>
                    </div>
                  </div>
                )}
              </div>
            )}

            {activeTab === 'staff' && (
              <div>
                <div className="flex justify-between items-center mb-6">
                  <h3 className="text-lg font-semibold text-gray-900">Staff Management</h3>
                  <button className="px-4 py-2 bg-primary-500 text-white rounded-lg hover:bg-primary-600 transition-colors">
                    Add Staff
                  </button>
                </div>

                <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                  <div>
                    <h4 className="text-md font-medium text-gray-700 mb-4">Staff List</h4>
                    <div className="space-y-3">
                      {mockStaff.map(staff => (
                        <div key={staff.id} className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                          <div>
                            <p className="font-medium text-gray-900">{staff.name}</p>
                            <p className="text-sm text-gray-600">{staff.position}</p>
                          </div>
                          <div className="text-right">
                            <p className="font-semibold text-gray-900">{formatCurrency(staff.salary)}</p>
                            <span className={`px-2 py-1 text-xs font-medium rounded-full ${
                              staff.isActive 
                                ? 'bg-green-100 text-green-800' 
                                : 'bg-gray-100 text-gray-800'
                            }`}>
                              {staff.isActive ? 'Active' : 'Inactive'}
                            </span>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>

                  <div>
                    <h4 className="text-md font-medium text-gray-700 mb-4">Today's Attendance</h4>
                    <div className="space-y-3">
                      {mockAttendance.map(attendance => {
                        const staff = mockStaff.find(s => s.id === attendance.staffId);
                        return (
                          <div key={attendance.id} className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                            <div>
                              <p className="font-medium text-gray-900">{staff?.name}</p>
                              <p className="text-sm text-gray-600">
                                {attendance.checkIn} - {attendance.checkOut || 'Working'}
                              </p>
                            </div>
                            <div className="text-right">
                              <p className="font-semibold text-gray-900">{attendance.hoursWorked}h</p>
                              <span className={`px-2 py-1 text-xs font-medium rounded-full ${
                                attendance.status === 'present' 
                                  ? 'bg-green-100 text-green-800'
                                  : attendance.status === 'halfday'
                                  ? 'bg-yellow-100 text-yellow-800'
                                  : 'bg-red-100 text-red-800'
                              }`}>
                                {attendance.status}
                              </span>
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                </div>
              </div>
            )}

            {activeTab === 'analytics' && (
              <div className="space-y-8">
                <SalesChart data={salesChartData} />
                
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  <div className="bg-gray-50 rounded-lg p-6">
                    <h4 className="text-lg font-semibold text-gray-900 mb-2">Total Revenue</h4>
                    <p className="text-3xl font-bold text-primary-600">{formatCurrency(156000)}</p>
                    <p className="text-sm text-gray-600 mt-1">This month</p>
                  </div>

                  <div className="bg-gray-50 rounded-lg p-6">
                    <h4 className="text-lg font-semibold text-gray-900 mb-2">Total Orders</h4>
                    <p className="text-3xl font-bold text-secondary-600">425</p>
                    <p className="text-sm text-gray-600 mt-1">This month</p>
                  </div>

                  <div className="bg-gray-50 rounded-lg p-6">
                    <h4 className="text-lg font-semibold text-gray-900 mb-2">Avg Order Value</h4>
                    <p className="text-3xl font-bold text-accent-600">{formatCurrency(367)}</p>
                    <p className="text-sm text-gray-600 mt-1">This month</p>
                  </div>
                </div>

                <div className="bg-white rounded-lg shadow-md p-6">
                  <h4 className="text-lg font-semibold text-gray-900 mb-4">Financial Summary</h4>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div className="space-y-3">
                      <div className="flex justify-between">
                        <span className="text-gray-600">Gross Revenue</span>
                        <span className="font-medium">{formatCurrency(156000)}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-600">GST (18%)</span>
                        <span className="font-medium">{formatCurrency(28080)}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-600">Staff Salaries</span>
                        <span className="font-medium">{formatCurrency(98000)}</span>
                      </div>
                      <div className="border-t border-gray-200 pt-3">
                        <div className="flex justify-between font-semibold text-lg">
                          <span>Net Profit</span>
                          <span className="text-green-600">{formatCurrency(29920)}</span>
                        </div>
                      </div>
                    </div>
                    <div className="space-y-3">
                      <div className="flex justify-between">
                        <span className="text-gray-600">Profit Margin</span>
                        <span className="font-medium text-green-600">19.2%</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-600">Cost Ratio</span>
                        <span className="font-medium">62.8%</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-600">Tax Ratio</span>
                        <span className="font-medium">18%</span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default RestaurantDashboard;