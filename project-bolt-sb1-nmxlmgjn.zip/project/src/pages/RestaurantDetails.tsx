import React, { useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import { Star, MapPin, Clock, Phone, Wifi, Car, Users, Calendar } from 'lucide-react';
import { mockRestaurants } from '../data/mockData';
import MenuCard from '../components/customer/MenuCard';
import Button from '../components/common/Button';
import { MenuItem, OrderItem } from '../types';

const RestaurantDetails = () => {
  const { id } = useParams<{ id: string }>();
  const [activeTab, setActiveTab] = useState<'overview' | 'menu' | 'book'>('overview');
  const [cart, setCart] = useState<OrderItem[]>([]);
  const [bookingDate, setBookingDate] = useState('');
  const [bookingTime, setBookingTime] = useState('');
  const [guests, setGuests] = useState(2);

  const restaurant = mockRestaurants.find(r => r.id === id);

  if (!restaurant) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <h2 className="text-2xl font-bold text-gray-900 mb-4">Restaurant not found</h2>
          <Link to="/restaurants" className="text-primary-500 hover:text-primary-600">
            Back to Restaurants
          </Link>
        </div>
      </div>
    );
  }

  const handleAddToCart = (item: MenuItem, quantity: number) => {
    setCart(prevCart => {
      const existingItem = prevCart.find(cartItem => cartItem.menuItemId === item.id);
      if (existingItem) {
        return prevCart.map(cartItem =>
          cartItem.menuItemId === item.id
            ? { ...cartItem, quantity }
            : cartItem
        ).filter(cartItem => cartItem.quantity > 0);
      } else if (quantity > 0) {
        return [...prevCart, { menuItemId: item.id, quantity }];
      }
      return prevCart;
    });
  };

  const getFeatureIcon = (feature: string) => {
    switch (feature.toLowerCase()) {
      case 'wifi':
        return <Wifi className="h-5 w-5" />;
      case 'parking':
        return <Car className="h-5 w-5" />;
      case 'ac':
        return <span className="text-sm font-semibold">AC</span>;
      default:
        return null;
    }
  };

  const totalCartAmount = cart.reduce((total, cartItem) => {
    const menuItem = restaurant.menu.find(item => item.id === cartItem.menuItemId);
    return total + (menuItem ? menuItem.price * cartItem.quantity : 0);
  }, 0);

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Restaurant Header */}
      <div className="bg-white shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 py-8">
            <div className="lg:col-span-2">
              <img
                src={restaurant.image}
                alt={restaurant.name}
                className="w-full h-64 object-cover rounded-lg"
              />
            </div>

            <div className="space-y-4">
              <div>
                <h1 className="text-3xl font-bold text-gray-900">{restaurant.name}</h1>
                <div className="flex items-center space-x-2 mt-2">
                  <div className="flex items-center">
                    <Star className="h-5 w-5 text-yellow-400 fill-current" />
                    <span className="ml-1 font-semibold">{restaurant.rating}</span>
                  </div>
                  <span className="text-gray-500">({restaurant.reviews} reviews)</span>
                  <span className="text-gray-500">•</span>
                  <span className="text-gray-500">{restaurant.priceRange}</span>
                </div>
              </div>

              <div className="space-y-3">
                <div className="flex items-center space-x-2 text-gray-600">
                  <MapPin className="h-5 w-5" />
                  <span>{restaurant.address}</span>
                </div>
                <div className="flex items-center space-x-2 text-gray-600">
                  <Clock className="h-5 w-5" />
                  <span>{restaurant.openingHours}</span>
                </div>
                <div className="flex items-center space-x-2 text-gray-600">
                  <Phone className="h-5 w-5" />
                  <span>{restaurant.phone}</span>
                </div>
              </div>

              <div className="flex flex-wrap gap-2">
                {restaurant.cuisine.map((cuisineType, index) => (
                  <span
                    key={index}
                    className="px-3 py-1 bg-primary-100 text-primary-700 text-sm rounded-full"
                  >
                    {cuisineType}
                  </span>
                ))}
              </div>

              <div className="flex space-x-4">
                {restaurant.features.map((feature, index) => (
                  <div
                    key={index}
                    className="flex items-center space-x-1 text-sm text-gray-600"
                  >
                    {getFeatureIcon(feature)}
                    <span>{feature}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Tabs */}
          <div className="border-b border-gray-200">
            <nav className="flex space-x-8">
              {[
                { id: 'overview', label: 'Overview' },
                { id: 'menu', label: 'Menu' },
                { id: 'book', label: 'Book Table' }
              ].map(tab => (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id as any)}
                  className={`py-4 px-1 border-b-2 font-medium text-sm ${
                    activeTab === tab.id
                      ? 'border-primary-500 text-primary-600'
                      : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
                  }`}
                >
                  {tab.label}
                </button>
              ))}
            </nav>
          </div>
        </div>
      </div>

      {/* Tab Content */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {activeTab === 'overview' && (
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            <div className="lg:col-span-2 space-y-6">
              <div className="bg-white rounded-lg shadow-md p-6">
                <h2 className="text-xl font-semibold text-gray-900 mb-4">About This Restaurant</h2>
                <p className="text-gray-600 leading-relaxed">
                  {restaurant.name} offers an authentic dining experience with a focus on traditional {restaurant.cuisine.join(', ')} cuisine. 
                  Our chefs use fresh, locally sourced ingredients to create memorable dishes that celebrate the rich culinary heritage of India.
                </p>
              </div>

              <div className="bg-white rounded-lg shadow-md p-6">
                <h2 className="text-xl font-semibold text-gray-900 mb-4">Location & Contact</h2>
                <div className="space-y-3">
                  <div className="flex items-start space-x-3">
                    <MapPin className="h-5 w-5 text-gray-400 mt-0.5" />
                    <div>
                      <p className="font-medium text-gray-900">Address</p>
                      <p className="text-gray-600">{restaurant.address}</p>
                    </div>
                  </div>
                  <div className="flex items-start space-x-3">
                    <Phone className="h-5 w-5 text-gray-400 mt-0.5" />
                    <div>
                      <p className="font-medium text-gray-900">Phone</p>
                      <p className="text-gray-600">{restaurant.phone}</p>
                    </div>
                  </div>
                  <div className="flex items-start space-x-3">
                    <Clock className="h-5 w-5 text-gray-400 mt-0.5" />
                    <div>
                      <p className="font-medium text-gray-900">Hours</p>
                      <p className="text-gray-600">{restaurant.openingHours}</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <div className="space-y-6">
              <div className="bg-white rounded-lg shadow-md p-6">
                <h3 className="text-lg font-semibold text-gray-900 mb-4">Quick Actions</h3>
                <div className="space-y-3">
                  <Button 
                    className="w-full"
                    onClick={() => setActiveTab('book')}
                  >
                    Book a Table
                  </Button>
                  <Button 
                    variant="outline" 
                    className="w-full"
                    onClick={() => setActiveTab('menu')}
                  >
                    View Menu
                  </Button>
                </div>
              </div>

              <div className="bg-white rounded-lg shadow-md p-6">
                <h3 className="text-lg font-semibold text-gray-900 mb-4">Table Availability</h3>
                <div className="flex items-center space-x-2 text-green-600">
                  <Users className="h-5 w-5" />
                  <span className="font-medium">
                    {restaurant.tables.filter(t => t.isAvailable).length} tables available
                  </span>
                </div>
              </div>
            </div>
          </div>
        )}

        {activeTab === 'menu' && (
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            <div className="lg:col-span-2">
              <h2 className="text-2xl font-bold text-gray-900 mb-6">Menu</h2>
              <div className="space-y-4">
                {restaurant.menu.map(item => (
                  <MenuCard
                    key={item.id}
                    item={item}
                    onAddToCart={handleAddToCart}
                  />
                ))}
              </div>
            </div>

            {cart.length > 0 && (
              <div className="bg-white rounded-lg shadow-md p-6 h-fit sticky top-4">
                <h3 className="text-lg font-semibold text-gray-900 mb-4">Your Order</h3>
                <div className="space-y-3 mb-4">
                  {cart.map(cartItem => {
                    const menuItem = restaurant.menu.find(item => item.id === cartItem.menuItemId);
                    if (!menuItem) return null;
                    return (
                      <div key={cartItem.menuItemId} className="flex justify-between">
                        <div>
                          <p className="font-medium">{menuItem.name}</p>
                          <p className="text-sm text-gray-600">Qty: {cartItem.quantity}</p>
                        </div>
                        <p className="font-medium">₹{menuItem.price * cartItem.quantity}</p>
                      </div>
                    );
                  })}
                </div>
                <div className="border-t border-gray-200 pt-3">
                  <div className="flex justify-between font-semibold text-lg">
                    <span>Total</span>
                    <span>₹{totalCartAmount}</span>
                  </div>
                </div>
                <Button className="w-full mt-4" onClick={() => setActiveTab('book')}>
                  Proceed to Book
                </Button>
              </div>
            )}
          </div>
        )}

        {activeTab === 'book' && (
          <div className="max-w-2xl mx-auto">
            <h2 className="text-2xl font-bold text-gray-900 mb-6">Book a Table</h2>
            <div className="bg-white rounded-lg shadow-md p-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Date
                  </label>
                  <input
                    type="date"
                    value={bookingDate}
                    onChange={(e) => setBookingDate(e.target.value)}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-primary-500"
                    min={new Date().toISOString().split('T')[0]}
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Time
                  </label>
                  <select
                    value={bookingTime}
                    onChange={(e) => setBookingTime(e.target.value)}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-primary-500"
                  >
                    <option value="">Select Time</option>
                    <option value="18:00">6:00 PM</option>
                    <option value="18:30">6:30 PM</option>
                    <option value="19:00">7:00 PM</option>
                    <option value="19:30">7:30 PM</option>
                    <option value="20:00">8:00 PM</option>
                    <option value="20:30">8:30 PM</option>
                    <option value="21:00">9:00 PM</option>
                  </select>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Number of Guests
                  </label>
                  <select
                    value={guests}
                    onChange={(e) => setGuests(Number(e.target.value))}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-primary-500"
                  >
                    {[1, 2, 3, 4, 5, 6, 7, 8].map(num => (
                      <option key={num} value={num}>{num} {num === 1 ? 'Guest' : 'Guests'}</option>
                    ))}
                  </select>
                </div>
              </div>

              {cart.length > 0 && (
                <div className="mb-6 p-4 bg-gray-50 rounded-lg">
                  <h4 className="font-medium text-gray-900 mb-3">Pre-order Summary</h4>
                  <div className="space-y-2">
                    {cart.map(cartItem => {
                      const menuItem = restaurant.menu.find(item => item.id === cartItem.menuItemId);
                      if (!menuItem) return null;
                      return (
                        <div key={cartItem.menuItemId} className="flex justify-between text-sm">
                          <span>{menuItem.name} x {cartItem.quantity}</span>
                          <span>₹{menuItem.price * cartItem.quantity}</span>
                        </div>
                      );
                    })}
                    <div className="border-t border-gray-200 pt-2 flex justify-between font-medium">
                      <span>Pre-order Total</span>
                      <span>₹{totalCartAmount}</span>
                    </div>
                  </div>
                </div>
              )}

              <Link
                to="/payment"
                state={{
                  restaurant,
                  booking: {
                    date: bookingDate,
                    time: bookingTime,
                    guests,
                    preOrder: cart,
                    totalAmount: totalCartAmount
                  }
                }}
              >
                <Button 
                  className="w-full" 
                  disabled={!bookingDate || !bookingTime}
                >
                  Continue to Payment
                </Button>
              </Link>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default RestaurantDetails;