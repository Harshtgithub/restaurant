export interface Restaurant {
  id: string;
  name: string;
  image: string;
  cuisine: string[];
  rating: number;
  reviews: number;
  priceRange: string;
  address: string;
  city: string;
  phone: string;
  openingHours: string;
  features: string[];
  tables: Table[];
  menu: MenuItem[];
}

export interface Table {
  id: string;
  number: number;
  capacity: number;
  isAvailable: boolean;
  pricePerHour?: number;
}

export interface MenuItem {
  id: string;
  name: string;
  description: string;
  price: number;
  category: string;
  image: string;
  isVeg: boolean;
  isAvailable: boolean;
  preparationTime: number;
}

export interface Booking {
  id: string;
  restaurantId: string;
  customerId: string;
  tableId: string;
  date: string;
  time: string;
  guests: number;
  status: 'pending' | 'confirmed' | 'cancelled' | 'completed';
  preOrder?: OrderItem[];
  totalAmount: number;
  paymentStatus: 'pending' | 'paid' | 'failed';
  paymentMethod?: 'upi' | 'netbanking' | 'cash';
}

export interface OrderItem {
  menuItemId: string;
  quantity: number;
  specialInstructions?: string;
}

export interface Customer {
  id: string;
  name: string;
  email: string;
  phone: string;
  bookings: Booking[];
}

export interface RestaurantOwner {
  id: string;
  name: string;
  email: string;
  restaurantIds: string[];
}

export interface Staff {
  id: string;
  name: string;
  position: string;
  salary: number;
  phone: string;
  email: string;
  joinDate: string;
  isActive: boolean;
}

export interface SalesRecord {
  id: string;
  date: string;
  bookingId: string;
  amount: number;
  gstAmount: number;
  netAmount: number;
  paymentMethod: string;
}

export interface Attendance {
  id: string;
  staffId: string;
  date: string;
  checkIn: string;
  checkOut?: string;
  hoursWorked: number;
  status: 'present' | 'absent' | 'halfday';
}